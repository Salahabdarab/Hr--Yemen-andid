export default function Home() {
  return <h1>Andid HR Yemen</h1>;
}
